from django.template.defaultfilters import length


def add_arrays(array):
    array2 = []
    for i in range(length(array)):
        wert = array[i] + 1500
        array2.append(wert)
    return array2

def count(array):
    wert = 0
    for i in range(length(array)):
        wert += 1
    return wert

def delete_inconsistent_values(array):
    array3 = []
    for i in range(length(array)):
        if i == 3 or i == 5 or i == 6 or i == 7 or i == 8 or i == 10 or i == 11 or i == 14 or i == 16 or i == 18 or i == 18 or i == 21 or i == 31 or \
                i == 47 or i == 48 or i == 58 or i == 62 or i == 63 or i == 66 or i == 68 or i == 81 or i == 92 or i == 95 or \
                i == 100 or i == 111 or i == 117 or i == 154 or i == 157 or i == 163 or i == 165 or i == 167 or i == 168 or \
                i == 174 or i == 182 or i == 202 or i == 205 or i == 218 or i == 244 or \
                i == 251 or i == 255 or i == 256 or i == 261 or i == 265 or i == 266 or i == 276 or i == 282 or \
                i == 292:
            print("deleted: ", array[i])

        else:
            array3.append(array[i])

    return array3


array_new = [26, 8, 11, 6, 4, 12, 24, 19, 5, 2, 0, 20, 14, 20, 13, 24, 8, 1, 26, 10, 38, 3, 13,
                                     0, 9, 36, 28, 1, 14, 5, 13, 15, 10, 9, 8, 15, 2, 0, 21, 30, 62, 2, 26, 26, 44, 13,
                                     0, 30, 38, 16, 15, 33, 13, 33, 42, 4, 9, 25, 7, 10, 67, 20, 0, 44, 16, 22, 13, 33,
                                     1, 27, 2, 18, 22, 1, 9, 17, 30, 21, 17, 21, 1, 8, 42, 16, 15, 11, 35, 20, 17, 32,
                                     22, 35, 23, 23, 15, 13, 14, 8, 14, 32, 37, 27, 12, 0, 35, 6, 11, 22, 20, 8, 43, 28,
                                     45, 13, 6, 0, 29, 45, 63, 42, 24, 0, 0, 56, 12, 19, 20, 0, 19, 19, 32, 38, 14, 36,
                                     3, 0, 1, 46, 6, 2, 11, 16, 29, 32, 27, 16, 54, 30, 0, 34, 18, 38, 32, 7, 12, 12,
                                     15, 15, 23, 23, 49, 0, 14, 48, 19, 0, 26, 25, 29, 11, 29, 33, 18, 6, 0, 21, 0, 0,
                                     19, 1, 16, 30, 26, 18, 3, 32, 16, 50, 26, 13, 17, 0, 1, 50, 5, 5, 5, 2, 0, 14, 11,
                                     16, 25, 11, 18, 51, 5, 8, 23, 9, 22, 12, 93, 30, 31, 0, 72, 32, 21, 15, 0, 0, 18,
                                     11, 43, 0, 54, 0, 8, 33, 9, 5, 63, 20, 8, 4, 26, 81, 12, 8, 13, 9, 12, 1, 74, 77,
                                     39, 30]
#array = delete_inconsistent_values(array_new)
array = count(array_new)
print(array)
